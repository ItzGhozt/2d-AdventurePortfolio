import { dialogueData, scaleFactor } from "./constants";
import { k } from "./kaboomCtx";
import { displayDialogue, setCamScale } from "./utils";

// Load YOUR custom avatar sprite (16 frames)
k.loadSprite("player", "/REAL.png", {
  sliceX: 16,  // 16 frames in your spritesheet
  sliceY: 1,   // 1 row
  anims: {
    // DOWN animations (frames 0-3)
    "idle-down": 0,
    "walk-down": { from: 0, to: 3, loop: true, speed: 3 },
    
    // UP animations (frames 4-7)
    "idle-up": 4,
    "walk-up": { from: 4, to: 7, loop: true, speed: 3 },
    
    // LEFT animations (frames 8-11)
    "idle-left": 8,
    "walk-left": { from: 8, to: 11, loop: true, speed: 3 },
    
    // RIGHT animations (frames 12-15)
    "idle-right": 12,
    "walk-right": { from: 12, to: 15, loop: true, speed: 3 },
  },
});

k.loadSprite("map", "/map.png");

k.setBackground(k.Color.fromHex("#588157"));

k.scene("main", async () => {
  const mapData = await (await fetch("/map.json")).json();
  const layers = mapData.layers;

  const map = k.add([k.sprite("map"), k.pos(0), k.scale(scaleFactor)]);

  const player = k.make([
    k.sprite("player", { anim: "idle-down" }),
    k.area({
      shape: new k.Rect(k.vec2(0, 3), 10, 10),
    }),
    k.body(),
    k.anchor("center"),
    k.pos(),
    k.scale(scaleFactor * 1.5),
    {
      speed: 150,
      direction: "down",
      isInDialogue: false,
    },
    "player",
  ]);

  for (const layer of layers) {
    if (layer.name === "boundaries") {
      // In your boundaries section, change to this:
for (const boundary of layer.objects) {
  const boundaryObj = [
    k.area({
      shape: new k.Rect(k.vec2(0), boundary.width, boundary.height),
    }),
    k.body({ isStatic: true }),
    k.pos(boundary.x, boundary.y),
    boundary.name,
  ];
  
  // Only add "boundary" tag to non-interactive objects (walls, etc)
  if (!dialogueData[boundary.name]) {
    boundaryObj.push("boundary");
  }
  
  map.add(boundaryObj);

  // Dialogue collision handler stays the same
  if (boundary.name && dialogueData[boundary.name]) {
    player.onCollide(boundary.name, () => {
      player.isInDialogue = true;
      displayDialogue(
        dialogueData[boundary.name],
        () => (player.isInDialogue = false)
      );
    });
  }
}
      continue;
    }

    if (layer.name === "Spawnpoint") {
      for (const entity of layer.objects) {
        if (entity.name === "Spawn") {
          player.pos = k.vec2(
            (map.pos.x + entity.x) * scaleFactor,
            (map.pos.y + entity.y) * scaleFactor
          );
          k.add(player);
          continue;
        }
      }
    }
  }

  setCamScale(k);

  k.onResize(() => {
    setCamScale(k);
  });

  k.onUpdate(() => {
    k.camPos(player.worldPos().x, player.worldPos().y - 100);
  });

  // MOUSE CONTROLS
  k.onMouseDown((mouseBtn) => {
    if (mouseBtn !== "left" || player.isInDialogue) return;

    const worldMousePos = k.toWorld(k.mousePos());
    player.moveTo(worldMousePos, player.speed);

    const mouseAngle = player.pos.angle(worldMousePos);

    const lowerBound = 50;
    const upperBound = 125;

    if (
      mouseAngle > lowerBound &&
      mouseAngle < upperBound &&
      player.curAnim() !== "walk-up"
    ) {
      player.play("walk-up");
      player.direction = "up";
      return;
    }

    if (
      mouseAngle < -lowerBound &&
      mouseAngle > -upperBound &&
      player.curAnim() !== "walk-down"
    ) {
      player.play("walk-down");
      player.direction = "down";
      return;
    }

    if (Math.abs(mouseAngle) > upperBound) {
      if (player.curAnim() !== "walk-right") player.play("walk-right");
      player.direction = "right";
      return;
    }

    if (Math.abs(mouseAngle) < lowerBound) {
      if (player.curAnim() !== "walk-left") player.play("walk-left");
      player.direction = "left";
      return;
    }
  });

  function stopAnims() {
    if (player.direction === "down") {
      player.play("idle-down");
      return;
    }
    if (player.direction === "up") {
      player.play("idle-up");
      return;
    }
    if (player.direction === "left") {
      player.play("idle-left");
      return;
    }
    if (player.direction === "right") {
      player.play("idle-right");
      return;
    }
  }

  k.onMouseRelease(stopAnims);

  // KEYBOARD CONTROLS - IMPROVED
  k.onKeyRelease(() => {

    const anyKeyPressed = 
      k.isKeyDown("right") || k.isKeyDown("d") ||
      k.isKeyDown("left") || k.isKeyDown("a") ||
      k.isKeyDown("up") || k.isKeyDown("w") ||
      k.isKeyDown("down") || k.isKeyDown("s");
    
    if (!anyKeyPressed) {
      stopAnims();
    }
  });

  k.onKeyDown((key) => {
    if (player.isInDialogue) return;

    // Count how many keys are pressed to prevent diagonal movement
    const keyMap = [
      k.isKeyDown("right") || k.isKeyDown("d"),
      k.isKeyDown("left") || k.isKeyDown("a"),
      k.isKeyDown("up") || k.isKeyDown("w"),
      k.isKeyDown("down") || k.isKeyDown("s"),
    ];

    let nbOfKeyPressed = 0;
    for (const pressed of keyMap) {
      if (pressed) {
        nbOfKeyPressed++;
      }
    }


    // RIGHT movement (D or Right Arrow)
    if (keyMap[0]) {
      if (player.curAnim() !== "walk-right") player.play("walk-right");
      player.direction = "right";
      player.move(player.speed, 0);
      return;
    }

    // LEFT movement (A or Left Arrow)
    if (keyMap[1]) {
      if (player.curAnim() !== "walk-left") player.play("walk-left");
      player.direction = "left";
      player.move(-player.speed, 0);
      return;
    }

    // UP movement (W or Up Arrow)
    if (keyMap[2]) {
      if (player.curAnim() !== "walk-up") player.play("walk-up");
      player.direction = "up";
      player.move(0, -player.speed);
      return;
    }

    // DOWN movement (S or Down Arrow)
    if (keyMap[3]) {
      if (player.curAnim() !== "walk-down") player.play("walk-down");
      player.direction = "down";
      player.move(0, player.speed);
    }
  });
});

k.go("main");